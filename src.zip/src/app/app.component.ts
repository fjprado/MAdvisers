import {Component, OnInit} from "@angular/core"

@Component({
  selector: 'cimp-app',
  templateUrl: 'app.component.html'
})
export class AppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
