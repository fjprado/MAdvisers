import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms'

import {ROUTES} from './app.routes'

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { SobreComponent } from './sobre/sobre.component';
import { InputComponent } from './shared/input/input.component';
import { TransporteComponent } from './agendamento-detalhe/transporte/transporte.component';
import { InformacoesComponent } from './agendamento-detalhe/informacoes/informacoes.component';
import { AgendamentoDetalheComponent } from './agendamento-detalhe/agendamento-detalhe.component';
import { AgendamentoComponent } from './agendamentos/agendamento/agendamento.component';
import { AgendamentosComponent } from './agendamentos/agendamentos.component';
import { AgendamentosService } from './agendamentos/agendamentos.service';
import { ApontamentosComponent } from './apontamentos/apontamentos.component';
import { RelogioPontoComponent } from './apontamentos/relogio-ponto/relogio-ponto.component';
import { RegistroApontamentoComponent } from './apontamentos/registro-apontamento/registro-apontamento.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    SobreComponent,
    InputComponent,
    TransporteComponent,
    InformacoesComponent,
    AgendamentoDetalheComponent,
    AgendamentoComponent,
    AgendamentosComponent,
    ApontamentosComponent,
    RelogioPontoComponent,
    RegistroApontamentoComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(ROUTES)    
  ],
  providers: [AgendamentosService, {provide: LOCALE_ID, useValue:'pt-BR'}],
  bootstrap: [AppComponent]
})
export class AppModule { }
