import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cimp-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
