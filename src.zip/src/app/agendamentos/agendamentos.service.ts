import {Injectable} from '@angular/core'
import {Http} from '@angular/http'
import {Observable} from 'rxjs/observable'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/catch'
import { ErrorHandler } from '../app.error-handler'

import { Agendamento } from './agendamento/agendamento.model'

import {CIMP_API} from '../app.api'

@Injectable()
export class AgendamentosService{
    
    
    constructor(private http: Http){}

    agendamentos(): Observable<Agendamento[]>{
        return this.http.get(`${CIMP_API}/agendamentos`)
            .map(response => response.json())
            .catch(ErrorHandler.handleError)
    }
    //retorna uma lista de itens Observable de Agendamento, capturadas do Json-Server e mapeados em Json.
    
    agendamentosPorId(id: string): Observable<Agendamento>{
        return this.http.get(`${CIMP_API}/agendamentos/${id}`)
            .map(response => response.json())
            .catch(ErrorHandler.handleError)
    }
    //retorna um item Observable de Agendamento através de seu ID, capturado do Json-Server e mapeado em Json.

    transporteDaImplantacao(id: string): Observable<any>{
        return this.http.get(`${CIMP_API}/agendamentos/${id}/transporte`)
            .map(response => response.json())
            .catch(ErrorHandler.handleError)
    }
 
    informacoesDaImplantacao(id: string): Observable<any>{
        return this.http.get(`${CIMP_API}/agendamentos/${id}/informacoes`)
            .map(response => response.json())
            .catch(ErrorHandler.handleError)
    }
 
 
 
    /*retorna uma lista de itens Observable do tipo Any(qualquer) 
    porém através do ID do Agendamento, capturadas do Json-Server e mapeados em Json*/




/*     menuOfRestaurants(id: string): Observable<MenuItem[]>{
        return this.http.get(`${CIMP_API}/agendamentos/${id}/informacoes`)
            .map(response => response.json())
            .catch(ErrorHandler.handleError)
    } */
}