export interface Agendamento{
    
    id: string
    concessionaria: string
    marca: string
    cidade: string
    uf: string
    dataInicio: Date
    dataTermino: Date
    sistema: string
    nomeResponsavel: string
    contatoResponsavel: string    
}