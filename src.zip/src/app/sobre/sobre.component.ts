import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cimp-sobre',
  templateUrl: './sobre.component.html'
})
export class SobreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
