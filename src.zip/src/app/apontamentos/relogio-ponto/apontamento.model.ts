export class Apontamento{
    constructor(public id: string, public dataHora: Date){
    }

}