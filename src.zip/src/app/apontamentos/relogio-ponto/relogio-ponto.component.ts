import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Apontamento } from './apontamento.model';

@Component({
  selector: 'cimp-relogio-ponto',
  templateUrl: './relogio-ponto.component.html'
})
export class RelogioPontoComponent implements OnInit {

  horaAtual: Date
  @Output() add = new EventEmitter()

  constructor() { 
    this.horaAtual = new Date
  }

  ngOnInit() {
  }

  horaApontamento(): Date{
    return this.horaAtual
  }

  emitAddEvent(){
    let apontamento: Apontamento = new Apontamento("0001",this.horaApontamento())
    this.add.emit(apontamento)
  }

}
