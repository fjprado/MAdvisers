import { ApontamentosService } from './../apontamentos.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cimp-registro-apontamento',
  templateUrl: './registro-apontamento.component.html'
})
export class RegistroApontamentoComponent implements OnInit {

  constructor(private apontamentosService: ApontamentosService) { }

  ngOnInit() {
  }

  items(): any[] {
    return this.apontamentosService.apontamentos;
  }

  addItem(apontamento: any){
    this.apontamentosService.addApontamento(apontamento)
  }

/*   totalDeHoras(): Date {
    return this.apontamentosService.totalDeHoras()
  }
 */
}
