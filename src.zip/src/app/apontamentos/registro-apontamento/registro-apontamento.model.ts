import {Apontamento} from '../relogio-ponto/apontamento.model'

export class RegistroApontamento {
  constructor(public apontamento: Apontamento){}
}
