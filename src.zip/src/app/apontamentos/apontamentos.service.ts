import {Injectable} from '@angular/core'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/catch'
import { ErrorHandler } from '../app.error-handler'

import { RegistroApontamento } from './registro-apontamento/registro-apontamento.model'
import { Apontamento } from './relogio-ponto/apontamento.model'
import {CIMP_API} from '../app.api'

export class ApontamentosService{

    constructor(){}
    
    apontamentos: RegistroApontamento[] = []

    addApontamento(apontamento: Apontamento){
        this.apontamentos.push(new RegistroApontamento(apontamento))
    }
    
/*     totalDeHoras(): Date{
        let totalHoras: Date
        let verificadorInicio: boolean = true
        let horaApontada: Date

        function somarHoras(item) : Date{
            if(verificadorInicio){
                horaApontada = item.getTime()
                verificadorInicio = false;
            }else{
                this.totalHoras = this.totalHoras.getTime() + (item.getTime() - horaApontada.getTime());
                verificadorInicio = true;
            }
            return this.totalHoras 
        }

        this.apontamentos.forEach(somarHoras)

        return totalHoras
    }

    registrosDeApontamento(id: string): Observable<Apontamento[]>{
        return this.http.get(`${CIMP_API}/apontamentos/${id}/registro-apontamento`)
            .map(response => response.json())
            .catch(ErrorHandler.handleError)
    } */
}